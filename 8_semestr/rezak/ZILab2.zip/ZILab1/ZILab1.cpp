﻿#include <iostream>
#include <string>

int getNum(char letter) {
    if (letter == ' ') // input with standart spaces
        return 26;
    return letter - 97;
}

char getLetter(int num) {
    if (num == 26)
        return '_'; // result with space symbol (if have it)
    return 97 + (num % 26);
}

int vizhiner(int x_i, int k_i) {
    return (x_i + k_i) % 27;
}
int bofort(int x_i, int k_i) {
    return ((x_i - k_i) >= 0 ? (x_i - k_i) % 26 : 27 - ((k_i - x_i) % 26)); // for circular alphabet
}

int main()
{
    int mode(0);
    std::cout << "   Mode:\n";
    std::cout << "1. Enciphering\n";
    std::cout << "2. Deciphering\n";
    std::cin >> mode;

    if (mode != 1 && mode != 2) {
        std::cout << "Exit...\n";
        return EXIT_SUCCESS;
    }
    std::cin.ignore();

    std::string sentence, keyword;
    int type(0);

    std::cout << "Enter sentence: ";
    std::getline(std::cin, sentence); // may be with spaces
    std::cout << "Enter keyword: ";
    std::getline(std::cin, keyword); // may be with spaces

    std::cout << "Enter type:\n";
    std::cout << "1. Vizhiner\n";
    std::cout << "2. Bofort\n";
    std::cin >> type;
    std::cin.ignore();

    if (type != 1 && type != 2) {
        std::cout << "Exit...\n";
        return EXIT_SUCCESS;
    }

    std::string result;
    if (mode == 1) {
        for(int i = 0; i < sentence.size(); ++i)
        {
            if (type == 1) {
                result.push_back(getLetter(vizhiner(getNum(sentence[i]), getNum(keyword[i % keyword.size()]))));
            }
            else {
                result.push_back(getLetter(bofort(getNum(sentence[i]), getNum(keyword[i % keyword.size()]))));
            }
        }
    }
    else {
        for (int i = 0; i < sentence.size(); ++i) {
            if (type == 1) {
                result.push_back(getLetter(bofort(getNum(sentence[i]), getNum(keyword[i % keyword.size()]))));
            }
            else {
                result.push_back(getLetter(vizhiner(getNum(sentence[i]), getNum(keyword[i % keyword.size()]))));
            }
        }
    }

    std::cout << "  Result: " << result << "\n";

    return EXIT_SUCCESS;
}

